

//interface IDbhelper
public interface IDbhelper2014302580181 {
	public void runUpdate(String sql);
	public void runUpdate(String sql,Object[] params);
}
