import java.io.IOException;
import java.sql.SQLException;


public class main2014302580386 {
	
	public static void main(String[] args) throws IOException, SQLException{
		singlethread2014302580386.main(args);;
		
		try {
			mulitthread2014302580386.main(args);
		} catch (InterruptedException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}

}
