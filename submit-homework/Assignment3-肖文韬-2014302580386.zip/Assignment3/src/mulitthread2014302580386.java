import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Comment;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class mulitthread2014302580386 extends Thread{
	public int i;
	public String url;
	public Document doc;
	public Connection con;
	public Conn2014302580386 test=new Conn2014302580386();
	
	public mulitthread2014302580386(int number){i=number;}
	
	public int number[]= new int[]{1627,1628,1577,1708};
		
	public void run(){
		try{
			PreparedStatement sql;
			con=test.getConnection();
			StringBuilder builder = new StringBuilder();
			//��ȡ
			url="http://cs.whu.edu.cn/plus/view.php?aid="+String.valueOf(number[i]);
			doc = Jsoup.connect(url).get(); 
			
			Element Content = doc.getElementsByClass("about_info").get(0);
			Element name = Content.getElementsByTag("li").get(0);
			Element phonenumber = Content.getElementsByTag("li").get(5);
			Element email = Content.getElementsByTag("li").get(7);
			//�������ݿ�
			sql=con.prepareStatement("insert into professor values(?,?,?,?);");
	        sql.setInt(1, i);
	        sql.setString(2, name.text());
	        sql.setString(3, phonenumber.text());
	        sql.setString(4, email.text());
	        sql.executeUpdate();
		    }catch(Exception e){
				e.printStackTrace();
			}
		}
	public static void main(String[] args) throws IOException, SQLException, InterruptedException {
		
		new singlethread2014302580386().run();
		
		mulitthread2014302580386 m[]=new mulitthread2014302580386[19];
		
		long start = System.currentTimeMillis();
		for(int j=0;j<4;j++){
			m[j]=new mulitthread2014302580386(j);
			m[j].start();
		
	    }
	
		for(int j=0;j<4;j++){
			m[j].join();;
			
	    }
		long end = System.currentTimeMillis();
		System.out.println("The time mulitthread used:"+(end-start));

	}
	
}
