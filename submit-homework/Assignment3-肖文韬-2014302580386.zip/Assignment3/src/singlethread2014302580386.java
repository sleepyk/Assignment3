import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Comment;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class singlethread2014302580386 {
	String url;
	Document doc;
	public Connection con;
	public Conn2014302580386 test=new Conn2014302580386();
	
	public void run() throws IOException, SQLException{
		int number[]= new int[]{1627,1628,1577,1708};
		for(int i=0;i<4;i++){
			PreparedStatement sql;
			con=test.getConnection();
			StringBuilder builder = new StringBuilder();
			
			url="http://cs.whu.edu.cn/plus/view.php?aid="+String.valueOf(number[i]);
			doc = Jsoup.connect(url).get();
			Element Content = doc.getElementsByClass("about_info").first();
			//System.out.println(Content.text());
			Element name = Content.getElementsByTag("li").get(1);
			Element phonenumber = Content.getElementsByTag("li").get(5);
			Element email = Content.getElementsByTag("li").get(7);
			
			sql=con.prepareStatement("insert into professor values(?,?,?,?);");
	        sql.setInt(1, i+1);
	        sql.setString(2, name.text());
	        sql.setString(3, phonenumber.text());
	        sql.setString(4, email.text());
	        sql.executeUpdate();
		    }
		}
	public static void main(String[] args) throws IOException, SQLException {
		long start2 = System.currentTimeMillis();              // ��ʼʱ��
		
		new singlethread2014302580386().run();
		
		long end2 = System.currentTimeMillis();                //����ʱ��
		System.out.println("The time SingleThread used:"+(end2-start2));

	}
}
	
